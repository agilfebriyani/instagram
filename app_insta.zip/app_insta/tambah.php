<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("location:login.php?login");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Document</title>
</head>
<body class = container style="max-width :600px;">
    <h1>Tambah Data</h1>

    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="">Foto</label><br>
        <input class = "form-control" type="file" name="foto" id="" required><br>
        <label for="">Caption</label><br>
        <input class = "form-control" type="text" name="caption" id="" autocomplete="off"><br>
        <label for="">Lokasi</label><br>
        <input class = "form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
        <input  class = "btn btn-primary" type="submit" value="Tambah" name="tambah">
    </form>
</body>
</html>