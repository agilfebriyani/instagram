<?php
$server = "localhost";
$user = "root";
$pass = "123456";
$database = "db_insta";

$koneksi = mysqli_connect($server,$user,$pass,$database);

// if($koneksi) {
//     "";
// }

?>